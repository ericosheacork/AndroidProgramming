package com.example.assignment1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import static android.content.DialogInterface.BUTTON_NEGATIVE;
import static android.content.DialogInterface.BUTTON_NEUTRAL;

public class Activity2 extends AppCompatActivity {

    TextView mainText2;
    Button returnButton;
    String resultString;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_2);
        mainText2 = findViewById(R.id.mainText2);
        returnButton = findViewById(R.id.returnButton);
        resultString = getIntent().getExtras().getString("result");
        mainText2.setText(resultString);




        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent(Activity2.this , MainActivity.class);
                startActivity(returnIntent);

            }
        });




    Bnotes}




}
