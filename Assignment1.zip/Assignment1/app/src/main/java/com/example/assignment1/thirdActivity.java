package com.example.assignment1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import static android.content.DialogInterface.BUTTON_NEGATIVE;
import static android.content.DialogInterface.BUTTON_NEUTRAL;

public class thirdActivity extends AppCompatActivity {

     private final String message ="Hello World";

    private void dialoguePopup()
    {


        AlertDialog ad = new AlertDialog.Builder(thirdActivity.this).create();
        ad.setTitle("Youve Won a car");
        ad.setMessage("would you like the car");


        ad.setButton(AlertDialog.BUTTON_POSITIVE , "Yay",
                new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog , int s)
                    {
                        Toast.makeText(getApplicationContext() , "Youve been scammed" , Toast.LENGTH_LONG).show();

                    }

                });

        ad.setButton(BUTTON_NEGATIVE, "Is this a scam",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext() , "What!!! NO!! SHUT UP!!!!" , Toast.LENGTH_LONG).show();
                    }
                });

        ad.setButton(BUTTON_NEUTRAL, "No thank you", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext() , "Ill get you next time" , Toast.LENGTH_LONG).show();

            }
        });


        ad.show();



    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        final Button evolveButton;
        Button superEvolve;
        Button megaEvolve;
        superEvolve = (Button) findViewById(R.id.superEvolve);
        megaEvolve = (Button) findViewById(R.id.megaEvolve);
        evolveButton = (Button) findViewById(R.id.evolveButton);
        dialoguePopup();


        evolveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int col = Color.CYAN;
                Intent intent = new Intent(thirdActivity.this, MainActivity.class);
                intent.putExtra("colorpassback", col);
                startActivity(intent);
                finish();



            }
        });

        superEvolve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int col = Color.MAGENTA;
                Intent intent = new Intent(thirdActivity.this , MainActivity.class);
                intent.putExtra("colorpassback" , col);
                startActivity(intent);
                finish();
            }
        });

        megaEvolve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int col = Color.GREEN;
                Intent intent = new Intent(thirdActivity.this , MainActivity.class);
                intent.putExtra("colorpassback" , col);
                startActivity(intent);
                finish();

            }
        });

    }
}
