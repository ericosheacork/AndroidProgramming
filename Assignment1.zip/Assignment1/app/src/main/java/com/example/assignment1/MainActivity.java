package com.example.assignment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;

import static android.content.DialogInterface.BUTTON_NEGATIVE;
import static android.content.DialogInterface.BUTTON_NEUTRAL;
import static android.content.DialogInterface.BUTTON_POSITIVE;

public class MainActivity extends AppCompatActivity {

EditText mainText;
Button hexButton;
Button textButton;
Button evolve;
TextView mainView;
RadioGroup radioGroup;


private final String NO_SPACES = "No Spaces";
private final String WHITESPACES = "White Space";
private final String SLASHES = "\\x";

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Name";
            String description = "Channwel";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("channel1", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

public void call()
{
    Toast.makeText(this , "Call" , Toast.LENGTH_SHORT).show();
    Intent callIntent = new Intent(Intent.ACTION_DIAL);
    callIntent.setData(Uri.parse("tel:0210000000"));
    PendingIntent pendingIntent = PendingIntent.getActivity(this , 0 , callIntent , PendingIntent.FLAG_UPDATE_CURRENT);
    Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
    NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this , "channel1")
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setContentTitle(getResources().getString(R.string.app_name))
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent);

            NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle();
            notificationBuilder.setStyle(inboxStyle);
            inboxStyle.setBigContentTitle("Call 021000000");
            inboxStyle.addLine("Call 02100000000");
            notificationBuilder.setStyle(inboxStyle);

    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    int nottificationID = 100;
    notificationManager.notify(nottificationID , notificationBuilder.build());


}

public String HexToText(String hex ) {

        //placing the function in a try catch to avoid errrors and setting the res default vlaue to error

    String res = "Error";

    try {
        byte[] bArray = new byte[hex.length() / 2];
        int i = 0;
        for (int j = 0; j < hex.length(); j += 2) {
            bArray[i++] = Byte.parseByte(hex.substring(j, j + 2), 16);
        }




          res = new String(bArray);


    } catch (NumberFormatException e) {
        e.printStackTrace();
    }

    return res;
}


    public String textTohex(String input , String format) {

        //repeating the code structure for the hex to text function to avcoid crashing also
        String res = "Error ";
        try {
            byte[] bArray = input.getBytes();
            StringBuilder sb = new StringBuilder();

            // switch performs the correct function based on the format value passed into it
            switch (format)
            {
                case NO_SPACES:
                    for (byte b : bArray) {
                        sb.append(String.format("%X", b));
                    }
                    break;

                case WHITESPACES:
                    for (byte b : bArray) {
                        sb.append(String.format("%X ", b));
                    }
                    break;

                case SLASHES:
                    for (byte b : bArray) {
                        sb.append(String.format("\\x%X", b));
                    }
                    break;


            }


            res = sb.toString();



        } catch (Exception e) {
            e.printStackTrace();
        }

        return res;
    }

    public void colorChange()
    {
        // function changes the backgrounf color based on the value passed in by activities 3 intent

        int getC = getIntent().getExtras().getInt("colorpassback");
        mainView.setBackgroundColor(getC);

    }


    //these two methods save the state of the textview on rotation
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString("textfield" , mainView.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        savedInstanceState.getString("textfield");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createNotificationChannel();

        //calling the saved text view by key as long as it is not null
        if(savedInstanceState != null)
        {
            String saved = savedInstanceState.getString("textField");
            mainView.setText(String.valueOf(saved));
        }





        //assigning button key values
        hexButton = (Button) findViewById(R.id.hexButton);
        textButton = findViewById(R.id.textButton);
        mainText = findViewById(R.id.mainText);
        mainView = findViewById(R.id.mainView);
        evolve = findViewById(R.id.evolve);
        radioGroup = findViewById(R.id.radioGroup);
        call();


        //placed in a try catch to avoid crashing
        try{
            int getC = getIntent().getExtras().getInt("colorpassback");
            mainView.setBackgroundColor(getC);
        } catch (Exception ex) {
            ex.printStackTrace();
        }



        // On click listener for the evolve button which will change the color of the texview
        evolve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String e = "EVOLVING";
                Intent thirdAct = new Intent(MainActivity.this , thirdActivity.class);
                thirdAct.putExtra("evolve" , e);
                startActivity(thirdAct);


//




            }
        });

        hexButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String result = "";
                radioGroup = findViewById(R.id.radioGroup);
                int selected = radioGroup.getCheckedRadioButtonId();
                RadioButton radioButton = findViewById(selected);
                String format = "No Spaces";
                try {
                     format = radioButton.getText().toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                //grabs the text form maintext
                String NO_SPACES = "No Spaces";
                String WHITESPACES = "White Space";
                String SLASHES = "\\x";
                String convert;
                String input = mainText.getText().toString();

                if(format.contentEquals(NO_SPACES))
                {
                    result = textTohex(input , NO_SPACES);
                }
                else if(format.contentEquals(WHITESPACES))
                {
                    result = textTohex(input , WHITESPACES);
                }

                else if(format.contentEquals(SLASHES))
                {
                    result = textTohex(input , SLASHES);
                }










                mainView.setText(result);
                mainText.setText(result);

            }
        });

        textButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String input = mainText.getText().toString();
               String result =  HexToText(input);

                Intent activity2 = new Intent(MainActivity.this , Activity2.class);
                activity2.putExtra("result" , result);

                startActivity(activity2);
              mainView.setText(result);
              mainText.setText(result);

            }
        });

        mainText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x =  "Enter text here";
                if(mainText.getText().toString().equals(x) )
                {
                    mainText.setText("");
                }


            }
        });











    }
}
